<!DOCTYPE html>
<html>
<head>
	<title>Handcracked's Admin home page</title>
</head>
<body>
	<h1> Handcracked Admin page  </h1>
</body>
</html>